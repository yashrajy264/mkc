class RomanticCanvas {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.hearts = [];
        this.sparkles = [];
        this.animationId = null;
        
        this.init();
        this.startAnimation();
    }
    
    init() {
        // Initialize floating hearts
        for (let i = 0; i < 8; i++) {
            this.hearts.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height + this.canvas.height,
                size: Math.random() * 20 + 10,
                speed: Math.random() * 2 + 1,
                opacity: Math.random() * 0.7 + 0.3,
                sway: Math.random() * 2 - 1
            });
        }
        
        // Initialize sparkles
        for (let i = 0; i < 15; i++) {
            this.sparkles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                size: Math.random() * 3 + 1,
                twinkle: Math.random() * Math.PI * 2,
                speed: Math.random() * 0.05 + 0.02
            });
        }
    }
    
    drawBackground() {
        const gradient = this.ctx.createLinearGradient(0, 0, this.canvas.width, this.canvas.height);
        gradient.addColorStop(0, '#fdf2f8');
        gradient.addColorStop(0.5, '#fce7f3');
        gradient.addColorStop(1, '#fdf2f8');
        
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    }
    
    drawMessage() {
        this.ctx.textAlign = 'center';
        
        // Draw main message
        this.ctx.fillStyle = '#be185d';
        this.ctx.font = 'bold 48px serif';
        this.ctx.fillText('I Love You ❤️', this.canvas.width / 2, 150);
        
        // Add shadow effect
        this.ctx.fillStyle = 'rgba(190, 24, 93, 0.3)';
        this.ctx.fillText('I Love You ❤️', this.canvas.width / 2 + 2, 152);
        
        // Draw secondary message
        this.ctx.fillStyle = '#ec4899';
        this.ctx.font = 'bold 28px serif';
        this.ctx.fillText('I Want to Be With You', this.canvas.width / 2, 220);
        
        // Add decorative hearts
        this.drawStaticHearts();
    }
    
    drawStaticHearts() {
        const hearts = ['💖', '💕', '💝', '💗'];
        const positions = [
            {x: 150, y: 120}, {x: 450, y: 120},
            {x: 100, y: 180}, {x: 500, y: 180},
            {x: 120, y: 240}, {x: 480, y: 240}
        ];
        
        this.ctx.font = '24px serif';
        positions.forEach((pos, index) => {
            this.ctx.fillStyle = '#f472b6';
            this.ctx.fillText(hearts[index % hearts.length], pos.x, pos.y);
        });
    }
    
    drawFloatingHearts() {
        this.hearts.forEach(heart => {
            this.ctx.save();
            this.ctx.globalAlpha = heart.opacity;
            this.ctx.font = `${heart.size}px serif`;
            this.ctx.fillStyle = '#ec4899';
            this.ctx.fillText('💕', heart.x, heart.y);
            this.ctx.restore();
            
            // Update position
            heart.y -= heart.speed;
            heart.x += Math.sin(heart.y * 0.01) * heart.sway;
            
            // Reset when off screen
            if (heart.y < -50) {
                heart.y = this.canvas.height + 50;
                heart.x = Math.random() * this.canvas.width;
            }
        });
    }
    
    drawSparkles() {
        this.sparkles.forEach(sparkle => {
            this.ctx.save();
            this.ctx.globalAlpha = Math.sin(sparkle.twinkle) * 0.5 + 0.5;
            this.ctx.fillStyle = '#fbbf24';
            this.ctx.beginPath();
            this.ctx.arc(sparkle.x, sparkle.y, sparkle.size, 0, Math.PI * 2);
            this.ctx.fill();
            this.ctx.restore();
            
            sparkle.twinkle += sparkle.speed;
        });
    }
    
    animate() {
        this.drawBackground();
        this.drawMessage();
        this.drawFloatingHearts();
        this.drawSparkles();
        
        this.animationId = requestAnimationFrame(() => this.animate());
    }
    
    startAnimation() {
        this.animate();
    }
    
    stopAnimation() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize romantic canvas
    const canvas = new RomanticCanvas('romanticCanvas');
    
    // Get button elements
    const yesButton = document.getElementById('yesButton');
    const noButton = document.getElementById('noButton');
    const modal = document.getElementById('successModal');
    
    // Track no button state
    let noButtonAttempts = 0;
    let isNoButtonEscaped = false;
    
    // Handle Yes button click
    yesButton.addEventListener('click', () => {
        console.log('Yes button clicked!');
        modal.classList.remove('hidden');
        createFloatingHearts();
        canvas.stopAnimation();
    });
    
    // Handle No button escape behavior
    function escapeNoButton() {
        noButtonAttempts++;
        isNoButtonEscaped = true;
        
        // Get viewport dimensions
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const buttonRect = noButton.getBoundingClientRect();
        
        // Calculate safe position (avoid edges)
        const margin = 50;
        const maxX = viewportWidth - buttonRect.width - margin;
        const maxY = viewportHeight - buttonRect.height - margin;
        
        const newX = Math.random() * (maxX - margin) + margin;
        const newY = Math.random() * (maxY - margin) + margin;
        
        // Apply new position
        noButton.style.position = 'fixed';
        noButton.style.left = `${newX}px`;
        noButton.style.top = `${newY}px`;
        noButton.style.zIndex = '1000';
        noButton.style.transition = 'all 0.2s ease-out';
        
        // Update button text
        const messages = [
            'Hey! 😮',
            'Stop it! 😤',
            'I said no! 😡', 
            'Seriously?! 😠',
            'You can\'t catch me! 😏',
            'Give up! 😈',
            'Never! 👿',
            'Fine... maybe? 😅'
        ];
        
        if (noButtonAttempts <= messages.length) {
            noButton.textContent = messages[noButtonAttempts - 1];
        } else {
            noButton.textContent = 'Okay okay! 😂';
        }
        
        // Add shake animation
        noButton.classList.add('shake');
        setTimeout(() => {
            noButton.classList.remove('shake');
        }, 500);
        
        console.log(`No button escaped to: ${newX}, ${newY} (attempt ${noButtonAttempts})`);
    }
    
    // Add event listeners to No button
    noButton.addEventListener('mouseenter', (e) => {
        e.preventDefault();
        escapeNoButton();
    });
    
    noButton.addEventListener('mouseover', (e) => {
        e.preventDefault(); 
        if (!isNoButtonEscaped) {
            escapeNoButton();
        }
    });
    
    noButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        escapeNoButton();
        return false;
    });
    
    noButton.addEventListener('touchstart', (e) => {
        e.preventDefault();
        escapeNoButton();
    });
    
    // Close modal functionality
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.add('hidden');
            canvas.startAnimation();
        }
    });
    
    // Create floating hearts effect
    function createFloatingHearts() {
        const hearts = ['❤️', '💕', '💖', '💗', '💝'];
        
        for (let i = 0; i < 20; i++) {
            setTimeout(() => {
                const heart = document.createElement('div');
                heart.className = 'floating-heart';
                heart.textContent = hearts[Math.floor(Math.random() * hearts.length)];
                heart.style.left = Math.random() * 100 + 'vw';
                heart.style.animationDelay = Math.random() * 2 + 's';
                heart.style.animationDuration = (Math.random() * 3 + 5) + 's';
                
                document.body.appendChild(heart);
                
                setTimeout(() => {
                    if (heart.parentNode) {
                        heart.parentNode.removeChild(heart);
                    }
                }, 8000);
            }, i * 300);
        }
    }
    
    // Add initial ambient hearts
    setTimeout(() => {
        for (let i = 0; i < 5; i++) {
            setTimeout(() => {
                const heart = document.createElement('div');
                heart.className = 'floating-heart';
                heart.textContent = '💕';
                heart.style.left = Math.random() * 100 + 'vw';
                heart.style.animationDelay = Math.random() * 5 + 's';
                
                document.body.appendChild(heart);
                
                setTimeout(() => {
                    if (heart.parentNode) {
                        heart.parentNode.removeChild(heart);
                    }
                }, 8000);
            }, i * 1000);
        }
    }, 2000);
    
    console.log('Romantic app initialized successfully!');
});